function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6bJcN8jc0pM":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

